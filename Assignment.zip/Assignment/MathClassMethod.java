class MathClassMethod{
    public static void main(String args[]){
        int x=12;
        int y=23;
        
        //Math class method for Maximum number
        System.out.println("The maximum number is:" +Math.max( x, y));
        
        //Math class method for Minimum number
        System.out.println("The minimum number is:"+Math.min(x, y));

        //Math class method for Square root of number
        System.out.println("The squre root of x is:"+Math.sqrt(x)+"\n The squre root of y is:"+Math.sqrt(y));

        //Math class method for power of x and y
        System.out.println("The power of x & y are:"+Math.pow(x,y));

         //Math class method for logarithm of number
         System.out.println("The logarithm of x is:"+Math.log(x)+"\n The logarithm of y is:"+Math.log(y));



    }
}