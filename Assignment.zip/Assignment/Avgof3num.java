/*Question 1 :Write a Java method to compute the averageof three numbers. */
public class Avgof3num {
    public static int Avg(int a, int b, int c){

        int avg=(a+b+c)/3;
        return avg;


    }
    public static void main(String args[]){
        System.out.print("The average of 3 numbers are: "+(int)Avg(4, 6, 8));

    }
    
}
